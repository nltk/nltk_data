#!/usr/share/python
# -*- encoding: utf-8 -*-
#
# Extract synset-word pairs from the MultiWordNet
#
# Creates one wordnet (Italian) linked from PWN 1.6 

import sys
import codecs
#import re

wndata= "/home/bond/work/wns/MWN_1.4.2/"

wnname = "MultiWordNet" 
wnurl = "http://multiwordnet.fbk.eu/english/home.php"
wnlicense = "CC BY 3.0"
wnlang= 'ita'

#
# header
#
outfile = "wn-data-%s.tab" % wnlang
out = codecs.open(outfile, "w", "utf-8" )
out.write("# %s\t%s\t%s\t%s \n" % (wnname, wnlang, wnurl, wnlicense))

###
### mappings
###
mapdir = "/home/bond/work/wn/mapps/mapping-16-30/"
maps = ["wn16-30.adj", "wn16-30.adv", "wn16-30.noun", "wn16-30.verb"]
pos = {"wn16-30.adj" : "a", "wn16-30.adv" : "r", 
       "wn16-30.noun" : "n", "wn16-30.verb" : "v", }
map1630 = dict();
for m in maps:
    mf = codecs.open(mapdir + m, "r", "utf-8" )
    p = pos[m]
    for l in mf:
        lst = l.strip().split()
        fsfrom = lst[0] + "-" + p
        fsto = sorted([(lst[i+1], lst[i]) for i in range(1,len(lst),2)])[-1][1]
        ##print "%s\t%s-%s" % (fsfrom, fsto, p)
        map1630[fsfrom] = "%s-%s" % (fsto, p)


    
##
## Data is in the file italian_synset.sql  
## synset\tlang\tgoodness\tlemma

f = codecs.open(wndata + "italian_synset.sql",  "rb", "utf-8")
log = codecs.open("log",  "w", "utf-8")

for l in f:
    if l.startswith("INSERT INTO italian_synset VALUES"):
        dat = l[35:-3].strip().replace('NULL', "''")[1:-1]
        ##print dat
        (wnid, words, phrases, defex) = dat.split("','")
        ss = '%s-%s' % (wnid[2:], wnid[0])
        if ss in map1630: ## lose new and unmappable synsets
            synset = map1630[ss]
            for lemma in words.strip().split(' '):
                lemma = lemma.replace("_", " ")
                lemma = lemma.replace("\\'", "'")
                if lemma:
                    out.write("%s\tlemma\t%s\n" % (synset, lemma))
        else:
            log.write("Unknown synset '%s'" % ss)

    ### FIXME also add gloss and examples

