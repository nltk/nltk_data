Pros and Cons

Source:
http://www.cs.uic.edu/~liub/FBS/pros-cons.rar

Attribution:
"Pros and cons dataset by Bing Liu [http://www.cs.uic.edu/~liub] is licensed under
CC BY 4.0 International [http://creativecommons.org/licenses/by/4.0/]"

NB: Line-endings have been converted from DOS to Unix, and some
characters have been converted from ISO-8859-1 to UTF-8.

Contact: Bing Liu, liub@cs.uic.edu
        http://www.cs.uic.edu/~liub

The data was used in the following papers:

Murthy Ganapathibhotla and Bing Liu. "Mining Opinions in Comparative Sentences".
    Proceedings of the 22nd International Conference on Computational Linguistics
    (Coling-2008), Manchester, 18-22 August, 2008.
    
Bing Liu, Minqing Hu and Junsheng Cheng. "Opinion Observer: Analyzing and Comparing
    Opinions on the Web". Proceedings of the 14th international World Wide Web
    conference (WWW-2005), May 10-14, 2005, in Chiba, Japan.
