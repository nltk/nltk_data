Opinion Lexicon

Available as ‘A list of positive and negative opinion words or
sentiment words for English’ from
http://www.cs.uic.edu/~liub/FBS/sentiment-analysis.html#datasets

Source:
http://www.cs.uic.edu/~liub/FBS/opinion-lexicon-English.rar

Attribution:
"Opinion Lexicon by Bing Liu [http://www.cs.uic.edu/~liub] is licensed under
CC BY 4.0 International [http://creativecommons.org/licenses/by/4.0/]"

NB: Some characters have been converted from ISO-8859-1 to UTF-8.

=======================================================

A list of positive and negative opinion words or sentiment words for
English (around 6800 words). This list was compiled over many years
starting from our first paper:

Minqing Hu and Bing Liu. "Mining and summarizing customer reviews."
Proceedings of the ACM SIGKDD International Conference on Knowledge
Discovery & Data Mining (KDD-2004, full paper), Seattle, Washington,
USA, Aug 22-25, 2004.
